﻿using System;
using System.Collections.Generic;
using System.Text;

namespace XaFirstMVVMNav.ViewModels
{
    class TryViewModel : BaseViewModel
    {
    }
}
